﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace TestProject
{
    class Program
    {
        static string _fileName => "Wordlist.txt"; //text file name containing list of words
        static string _delimiter => " ";
        static string _lineBreak => "\r\n";

        static void Main(string[] args)
        {
            //READ WORD FROM TEST FILE
            List<string> lstWords = ReadTestFile(_fileName);

            Console.WriteLine("************************ Welcome *************************************");

            //CHECK IF FILE CONTAINS WORD
            if (lstWords != null && lstWords.Count > 0)
            {

                //ASK THE USER FOR WORD INPUT
                Console.WriteLine("\n\n Please enter the word and press enter: ");

                //READ USER INPUT
                string strInputWord = Console.ReadLine();

                //CHECK IF INPUT IS NOT NULL
                if (!string.IsNullOrEmpty(strInputWord))
                {
                    //REVERSE USER INPUT
                    string reverseString = new string(strInputWord.Reverse().ToArray());

                    //CHECK IF REVERSE WORD AVALABLE IN LIST
                    string isAnagramPResent = lstWords.Where(v => v == (reverseString)).FirstOrDefault();

                    if (!string.IsNullOrEmpty(isAnagramPResent))
                    {
                        Console.WriteLine("Congratulations !! We have found anagram of your word and the result is : " + isAnagramPResent);
                    }
                    else
                    {
                        Console.WriteLine("Oops! No anagram word found for your input.");
                    }
                }
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Oops! Seems like no word available in file. Please check and try again.");
            }
        }

        /// <summary>
        /// RETURN LIST OF WORD IN TEXT FILE
        /// </summary>
        /// <param name="fileName">FILE NAME CONTAINING WORD LIST </param>
        /// <returns></returns>
        static List<string> ReadTestFile(string fileName)
        {
            string fileContents;

            using (var fileStream = new FileStream(fileName, FileMode.Open, FileAccess.Read))
            {
                using (var streamReader = new StreamReader(fileStream))
                {
                    fileContents = streamReader.ReadToEnd();
                }

                var separators = string.Join("", _lineBreak, _delimiter).ToCharArray();
                var query = from item in fileContents
                             .Split(separators, StringSplitOptions.RemoveEmptyEntries)
                            select(item);

                return query.ToList();
            }
        }

    }
}
